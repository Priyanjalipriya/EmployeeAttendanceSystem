<!DOCTYPE html>
<?php
	include 'auth.php';
	  require 'db_connect.php';
?>
<html lang = "eng">
	<head>
		<title>Simple Employee Attendance Record System</title>
		<?php include 'header.php'; ?>
	</head>
	<body>
		<?php include 'nav_bar.php' ?>
		<div class = "container-fluid admin" >
			
			<div class = "alert alert-primary">Dashboard</div>
			<h5>Welcome <?php echo ucwords($user_name) ?> !</h5>

			<!-- showing total male and female candidate -->
			<!-- <div class="container"> -->
				<div class="row">
					   <div class="col-md-4">
			               <div class="card" style="width: 10rem;">
                                <div class="card-body">
                                    <h5 class="card-title">Male</h5>
                                    <?php
                                  
                                    $query= "SELECT * FROM employee where Gender='male'";   
                                    $query_run=mysqli_query($conn,$query);
                                    $row1=mysqli_num_rows($query_run);
                                    echo'<h5>'.$row1.'</h5>';

                                    ?>
                                 </div>
                           </div>
                       </div> 
                        <div class="col-md-4">
                            <div class="card" style="width: 10rem;">
                                <div class="card-body">
                                    <h5 class="card-title">Female</h5>
                                    <?php
                                
                                    $query= "SELECT * FROM employee where Gender='female'";   
                                    $query_run=mysqli_query($conn,$query);
                                    $row=mysqli_num_rows($query_run);
                                    echo'<h5>'.$row.'</h5>';

                                    ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card" style="width: 10rem;">
                                <div class="card-body">
                                    <h5 class="card-title">Total</h5>
                                    
                                    <?php
                            
                                    $query= "SELECT * FROM employee";   
                                    $query_run=mysqli_query($conn,$query);
                                    $row=mysqli_num_rows($query_run);
                                    echo'<h5>'.$row.'</h5>';

                                    ?>
                                   
                                </div>
                            </div>
                        </div>
                </div>
            <!-- </div> -->
</div>
</body>
	
	
</html>