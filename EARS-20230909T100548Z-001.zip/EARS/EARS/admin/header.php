	
	<meta charset = "utf-8" />
		<link rel = "stylesheet" type = "text/css" href = "../assets/css/bootstrap.min.css" />
		<link rel = "stylesheet" type = "text/css" href = "https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
		<link rel = "stylesheet" type = "text/css" href = "https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" />
		<link rel = "stylesheet" type = "text/css" href = "../assets/css/style.css" />

	<script src = "../assets/js/jquery-3.5.1.min.js"></script>
	<script src = "../assets/js/bootstrap.min.js"></script>
	<script src = "https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>